create definer = root@localhost view select_dibs_by_user_view as
select `d`.`user_id`  AS `user_id`,
       `d`.`no`       AS `dibs_no`,
       `p`.`no`       AS `product_no`,
       `p`.`name`     AS `product_name`,
       `p`.`price`    AS `product_price`,
       `p`.`category` AS `product_category`,
       `pi`.`no`      AS `product_image_no`
from ((`style`.`dibs` `d` join `style`.`product` `p`
       on ((`d`.`product_no` = `p`.`no`))) join `style`.`product_image` `pi` on ((`p`.`no` = `pi`.`product_no`)));

