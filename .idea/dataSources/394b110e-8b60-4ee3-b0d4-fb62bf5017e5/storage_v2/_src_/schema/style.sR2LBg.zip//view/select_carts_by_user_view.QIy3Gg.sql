create definer = root@localhost view select_carts_by_user_view as
select `p`.`no`    AS `product_no`,
       `p`.`name`  AS `product_name`,
       `p`.`price` AS `product_price`,
       `pi`.`no`   AS `product_image_no`
from (`style`.`product` `p` join `style`.`product_image` `pi` on ((`p`.`no` = `pi`.`product_no`)));

